package com.example.leaseorrent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity8 extends AppCompatActivity {
    Button button8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);
        final EditText date = (EditText)findViewById(R.id.et_expirydate);
        final EditText date1 = (EditText) findViewById(R.id.et_name);
        final EditText date2 = (EditText)findViewById(R.id.et_card);
        final EditText date3 = (EditText)findViewById(R.id.et_cvv);
        final EditText date4 = (EditText)findViewById(R.id.et_security);
        button8=(Button)findViewById(R.id.button9);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String d1=date1.getText().toString();

                if(d1.length()==0){
                    Toast.makeText(MainActivity8.this,"NAME CANNOT BE EMPTY",Toast.LENGTH_LONG).show();
                }
                else if(!d1.matches("[a-zA-Z]+")){
                    Toast.makeText(MainActivity8.this,"Alphabets Only",Toast.LENGTH_LONG).show();
                }
                else {
                    Intent int1 = new Intent(MainActivity8.this, MainActivity2.class);
                    startActivity(int1);
                }
            }
        });
    }

}