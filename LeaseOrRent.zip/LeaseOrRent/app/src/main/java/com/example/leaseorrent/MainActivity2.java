package com.example.leaseorrent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity  {

    Button button8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


            button8 = findViewById(R.id.button8);

            button8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity2.this, MainActivity8.class);
                    startActivity(intent);
                }
            });

        ImageView myImageView = (ImageView) findViewById(R.id.imageView);
        myImageView.setImageResource(R.drawable.logo1);

        Spinner spinner;
        spinner = findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.ListHouseType, R.layout.color_spinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {


            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 1) {
                    startActivity(new Intent(MainActivity2.this, MainActivity3.class));
                }else
                    if(position == 2) {
                        startActivity(new Intent(MainActivity2.this, MainActivity4.class));
                    }else
                    if(position == 3) {
                        startActivity(new Intent(MainActivity2.this, MainActivity5.class));
                    }else
                    if(position == 4) {
                        startActivity(new Intent(MainActivity2.this, MainActivity6.class));
                    }else
                    if(position == 5) {
                        startActivity(new Intent(MainActivity2.this, MainActivity7.class));
                    }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}

